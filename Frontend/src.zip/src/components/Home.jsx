import React from 'react';
import { Link } from 'react-router-dom';
import { FaSun, FaMoon, FaBook, FaGraduationCap, FaUsers, FaLaptopCode, FaCertificate, FaBars, FaTimes } from 'react-icons/fa';
import { RiGraduationCapFill } from 'react-icons/ri';
import { useTheme } from '../context/ThemeContext';

const Home = () => {
  const { isDarkMode, toggleTheme } = useTheme();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  const features = [
    {
      icon: <FaBook className="text-3xl" />,
      title: "Interactive Learning",
      description: "Engage with dynamic content and real-world projects"
    },
    {
      icon: <FaGraduationCap className="text-3xl" />,
      title: "Expert Instructors",
      description: "Learn from industry professionals and experienced educators"
    },
    {
      icon: <FaUsers className="text-3xl" />,
      title: "Community Learning",
      description: "Collaborate with peers and share knowledge"
    },
    {
      icon: <FaLaptopCode className="text-3xl" />,
      title: "Hands-on Practice",
      description: "Apply your skills with practical exercises and projects"
    },
    {
      icon: <FaCertificate className="text-3xl" />,
      title: "Certification",
      description: "Earn certificates upon course completion"
    }
  ];

  return (
    <div className={`min-h-screen ${isDarkMode ? 'bg-gray-900' : 'bg-gray-50'}`}>
      {/* Theme Toggle Button */}
      <button
        onClick={toggleTheme}
        className={`fixed top-4 right-4 p-3 rounded-full transition-all duration-300 z-50 ${
          isDarkMode
            ? 'bg-gray-700 text-yellow-400 hover:bg-gray-600 shadow-lg'
            : 'bg-white text-gray-800 hover:bg-gray-100 shadow-lg'
        }`}
      >
        {isDarkMode ? <FaSun size={20} /> : <FaMoon size={20} />}
      </button>

      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-40 backdrop-blur-sm ${
        isDarkMode 
          ? 'bg-gray-900/80 border-b border-gray-800' 
          : 'bg-white/80 border-b border-gray-200'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className={`p-2 rounded-xl shadow-lg ${
                isDarkMode
                  ? 'bg-gradient-to-br from-blue-500 via-indigo-500 to-purple-500'
                  : 'bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600'
              }`}>
                <RiGraduationCapFill className="text-2xl text-white" />
              </div>
              <span className={`ml-2 text-xl font-semibold ${
                isDarkMode ? 'text-white' : 'text-gray-900'
              }`}>EduSkillX</span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <Link to="/courses" className={`font-medium transition-all duration-200 ${
                isDarkMode
                  ? 'text-gray-300 hover:text-white'
                  : 'text-gray-600 hover:text-gray-900'
              }`}>
                Courses
              </Link>
              <Link to="/about" className={`font-medium transition-all duration-200 ${
                isDarkMode
                  ? 'text-gray-300 hover:text-white'
                  : 'text-gray-600 hover:text-gray-900'
              }`}>
                About
              </Link>
              <Link to="/contact" className={`font-medium transition-all duration-200 ${
                isDarkMode
                  ? 'text-gray-300 hover:text-white'
                  : 'text-gray-600 hover:text-gray-900'
              }`}>
                Contact
              </Link>
              <Link to="/login" className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                isDarkMode
                  ? 'text-gray-300 hover:text-white'
                  : 'text-gray-600 hover:text-gray-900'
              }`}>
                Sign In
              </Link>
              <Link to="/signup" className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                isDarkMode
                  ? 'bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 text-white hover:opacity-90'
                  : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white hover:opacity-90'
              }`}>
                Get Started
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 rounded-lg"
            >
              {isMenuOpen ? (
                <FaTimes className={`text-2xl ${isDarkMode ? 'text-white' : 'text-gray-900'}`} />
              ) : (
                <FaBars className={`text-2xl ${isDarkMode ? 'text-white' : 'text-gray-900'}`} />
              )}
            </button>
          </div>

          {/* Mobile Navigation */}
          <div className={`md:hidden transition-all duration-300 ease-in-out ${
            isMenuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
          } overflow-hidden`}>
            <div className="py-4 space-y-4">
              <Link to="/courses" className={`block font-medium transition-all duration-200 ${
                isDarkMode
                  ? 'text-gray-300 hover:text-white'
                  : 'text-gray-600 hover:text-gray-900'
              }`}>
                Courses
              </Link>
              <Link to="/about" className={`block font-medium transition-all duration-200 ${
                isDarkMode
                  ? 'text-gray-300 hover:text-white'
                  : 'text-gray-600 hover:text-gray-900'
              }`}>
                About
              </Link>
              <Link to="/contact" className={`block font-medium transition-all duration-200 ${
                isDarkMode
                  ? 'text-gray-300 hover:text-white'
                  : 'text-gray-600 hover:text-gray-900'
              }`}>
                Contact
              </Link>
              <Link to="/login" className={`block px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                isDarkMode
                  ? 'text-gray-300 hover:text-white'
                  : 'text-gray-600 hover:text-gray-900'
              }`}>
                Sign In
              </Link>
              <Link to="/signup" className={`block px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                isDarkMode
                  ? 'bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 text-white hover:opacity-90'
                  : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white hover:opacity-90'
              }`}>
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-16 px-4 relative overflow-hidden">
        {/* Background Decoration */}
        <div className={`absolute inset-0 ${
          isDarkMode
            ? 'bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900'
            : 'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50'
        }`}>
          {!isDarkMode && (
            <>
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-indigo-100/40 via-transparent to-transparent"></div>
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,_var(--tw-gradient-stops))] from-blue-100/40 via-transparent to-transparent"></div>
            </>
          )}
        </div>

        <div className="max-w-7xl mx-auto relative">
          <div className="text-center">
            <h1 className={`text-4xl sm:text-5xl md:text-6xl font-bold mb-6 leading-tight ${
              isDarkMode
                ? 'bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-400 bg-clip-text text-transparent'
                : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent'
            }`}>
              Transform Your Learning Journey
            </h1>
            <p className={`text-lg sm:text-xl md:text-2xl mb-8 max-w-3xl mx-auto ${
              isDarkMode ? 'text-gray-300' : 'text-gray-600'
            }`}>
              Access world-class education, connect with experts, and advance your career
            </p>
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <Link to="/signup" className={`px-6 py-3 rounded-xl font-medium shadow-lg hover:shadow-xl transition-all duration-200 ${
                isDarkMode
                  ? 'bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 text-white hover:opacity-90'
                  : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white hover:opacity-90'
              }`}>
                Start Learning
              </Link>
              <Link to="/courses" className={`px-6 py-3 rounded-xl font-medium shadow-lg hover:shadow-xl transition-all duration-200 ${
                isDarkMode
                  ? 'bg-gray-800 text-white hover:bg-gray-700'
                  : 'bg-white text-gray-900 hover:bg-gray-50'
              }`}>
                Explore Courses
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className={`py-16 px-4 ${isDarkMode ? 'bg-gray-800' : 'bg-white'}`}>
        <div className="max-w-7xl mx-auto">
          <h2 className={`text-3xl md:text-4xl font-bold text-center mb-4 ${
            isDarkMode ? 'text-white' : 'text-gray-900'
          }`}>
            Why Choose EduSkillX?
          </h2>
          <p className={`text-center mb-12 max-w-2xl mx-auto ${
            isDarkMode ? 'text-gray-400' : 'text-gray-600'
          }`}>
            Experience the future of education with our innovative learning platform
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {features.map((feature, index) => (
              <div key={index} className={`p-6 rounded-2xl transition-all duration-200 hover:scale-105 ${
                isDarkMode
                  ? 'bg-gray-700/50 hover:bg-gray-700'
                  : 'bg-gray-50 hover:bg-white'
              }`}>
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${
                  isDarkMode
                    ? 'bg-gradient-to-br from-blue-500 via-indigo-500 to-purple-500'
                    : 'bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600'
                }`}>
                  <div className="text-white">{feature.icon}</div>
                </div>
                <h3 className={`text-xl font-semibold mb-2 ${
                  isDarkMode ? 'text-white' : 'text-gray-900'
                }`}>
                  {feature.title}
                </h3>
                <p className={isDarkMode ? 'text-gray-300' : 'text-gray-600'}>
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 relative overflow-hidden">
        <div className={`absolute inset-0 ${
          isDarkMode
            ? 'bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900'
            : 'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50'
        }`}>
          {!isDarkMode && (
            <>
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-indigo-100/40 via-transparent to-transparent"></div>
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,_var(--tw-gradient-stops))] from-blue-100/40 via-transparent to-transparent"></div>
            </>
          )}
        </div>
        <div className="max-w-4xl mx-auto text-center relative">
          <h2 className={`text-3xl md:text-4xl font-bold mb-6 ${
            isDarkMode ? 'text-white' : 'text-gray-900'
          }`}>
            Ready to Start Learning?
          </h2>
          <p className={`text-lg md:text-xl mb-8 ${
            isDarkMode ? 'text-gray-300' : 'text-gray-600'
          }`}>
            Join thousands of learners who are already transforming their careers with EduSkillX
          </p>
          <Link to="/signup" className={`inline-block px-8 py-4 rounded-xl font-medium shadow-lg hover:shadow-xl transition-all duration-200 ${
            isDarkMode
              ? 'bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 text-white hover:opacity-90'
              : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white hover:opacity-90'
          }`}>
            Get Started Now
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className={`py-8 px-4 ${isDarkMode ? 'bg-gray-900 border-t border-gray-800' : 'bg-white border-t border-gray-200'}`}>
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <div className={`p-2 rounded-xl shadow-lg ${
                  isDarkMode
                    ? 'bg-gradient-to-br from-blue-500 via-indigo-500 to-purple-500'
                    : 'bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600'
                }`}>
                  <RiGraduationCapFill className="text-2xl text-white" />
                </div>
                <span className={`ml-2 text-xl font-semibold ${
                  isDarkMode ? 'text-white' : 'text-gray-900'
                }`}>EduSkillX</span>
              </div>
              <p className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
                Empowering learners worldwide with quality education
              </p>
            </div>
            <div>
              <h3 className={`text-lg font-semibold mb-4 ${
                isDarkMode ? 'text-white' : 'text-gray-900'
              }`}>Quick Links</h3>
              <ul className="space-y-2">
                <li><Link to="/courses" className={isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-600 hover:text-gray-900'}>Courses</Link></li>
                <li><Link to="/about" className={isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-600 hover:text-gray-900'}>About Us</Link></li>
                <li><Link to="/contact" className={isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-600 hover:text-gray-900'}>Contact</Link></li>
              </ul>
            </div>
            <div>
              <h3 className={`text-lg font-semibold mb-4 ${
                isDarkMode ? 'text-white' : 'text-gray-900'
              }`}>Support</h3>
              <ul className="space-y-2">
                <li><Link to="/faq" className={isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-600 hover:text-gray-900'}>FAQ</Link></li>
                <li><Link to="/privacy" className={isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-600 hover:text-gray-900'}>Privacy Policy</Link></li>
                <li><Link to="/terms" className={isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-600 hover:text-gray-900'}>Terms of Service</Link></li>
              </ul>
            </div>
            <div>
              <h3 className={`text-lg font-semibold mb-4 ${
                isDarkMode ? 'text-white' : 'text-gray-900'
              }`}>Connect</h3>
              <ul className="space-y-2">
                <li><Link to="/blog" className={isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-600 hover:text-gray-900'}>Blog</Link></li>
                <li><Link to="/newsletter" className={isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-600 hover:text-gray-900'}>Newsletter</Link></li>
                <li><Link to="/social" className={isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-600 hover:text-gray-900'}>Social Media</Link></li>
              </ul>
            </div>
          </div>
          <div className={`mt-8 pt-8 border-t text-center ${
            isDarkMode ? 'border-gray-800 text-gray-400' : 'border-gray-200 text-gray-600'
          }`}>
            <p>© 2024 EduSkillX. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;
