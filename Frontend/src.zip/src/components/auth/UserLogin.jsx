import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FaEye, FaEyeSlash, FaGoogle, FaFacebook, FaSun, FaMoon } from 'react-icons/fa';
import { RiGraduationCapFill } from 'react-icons/ri';
import { useTheme } from '../../context/ThemeContext';
import ErrorPopup from '../ErrorPopup';
import axios from 'axios';

const UserLogin = () => {
  const { isDarkMode, toggleTheme } = useTheme();
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await axios.post(`${import.meta.env.VITE_BASE_URI}/auth/login`, formData);
      const { token, user } = response.data;
      localStorage.setItem('token', token);
      localStorage.setItem('userRole', user.role);
      localStorage.setItem('userId', user.id);
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'An error occurred during login');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`min-h-screen flex items-center justify-center p-4 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900' 
        : 'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50'
    }`}>
      {/* Error Popup */}
      <ErrorPopup 
        error={error} 
        onClose={() => setError('')}
      />

      {/* Theme Toggle Button - Moved outside the card */}
      <button
        onClick={toggleTheme}
        className={`fixed top-4 right-4 p-3 rounded-full transition-all duration-300 z-50 ${
          isDarkMode
            ? 'bg-gray-700 text-yellow-400 hover:bg-gray-600 shadow-lg'
            : 'bg-white text-gray-800 hover:bg-gray-100 shadow-lg'
        }`}
      >
        {isDarkMode ? <FaSun size={20} /> : <FaMoon size={20} />}
      </button>

      {!isDarkMode && (
        <>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-indigo-100/40 via-transparent to-transparent"></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,_var(--tw-gradient-stops))] from-blue-100/40 via-transparent to-transparent"></div>
        </>
      )}
      
      <div className="w-full max-w-[400px] relative">
        {/* Left side decorative element */}
        <div className={`absolute -left-6 top-1/2 -translate-y-1/2 w-1 h-32 rounded-full ${
          isDarkMode
            ? 'bg-gradient-to-b from-blue-500 via-indigo-500 to-purple-500'
            : 'bg-gradient-to-b from-blue-600 via-indigo-600 to-purple-600'
        }`}></div>

        <div className={`backdrop-blur-sm rounded-2xl p-10 ${
          isDarkMode
            ? 'bg-gray-800/50 shadow-[0_20px_50px_rgba(0,_0,_0,_0.3)] border border-gray-700'
            : 'bg-white/70 shadow-[0_20px_50px_rgba(8,_112,_184,_0.07)] border border-white/50'
        }`}>
          {/* Logo and Title */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-6">
              <div className={`p-3 rounded-2xl shadow-lg transform hover:scale-105 transition-transform duration-300 ${
                isDarkMode
                  ? 'bg-gradient-to-br from-blue-500 via-indigo-500 to-purple-500'
                  : 'bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600'
              }`}>
                <RiGraduationCapFill className="text-4xl text-white" />
              </div>
            </div>
            <h1 className={`text-2xl font-semibold mb-2 ${
              isDarkMode
                ? 'bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-400 bg-clip-text text-transparent'
                : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent'
            }`}>Welcome Back</h1>
            <p className={isDarkMode ? 'text-gray-400 text-sm' : 'text-gray-600 text-sm'}>
              Sign in to continue your learning journey
            </p>
          </div>

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Email Input */}
            <div>
              <label className={`block text-sm font-medium mb-1.5 ${
                isDarkMode ? 'text-gray-300' : 'text-gray-700'
              }`}>
                Email address
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className={`w-full px-4 py-3 rounded-xl border transition-all duration-200 ${
                  isDarkMode
                    ? 'bg-gray-700/50 border-gray-600 focus:bg-gray-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-gray-100 placeholder:text-gray-500'
                    : 'bg-white/50 border-gray-200 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 text-gray-600 placeholder:text-gray-400'
                }`}
                placeholder="Enter your email"
                required
              />
            </div>

            {/* Password Input */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className={`block text-sm font-medium ${
                  isDarkMode ? 'text-gray-300' : 'text-gray-700'
                }`}>
                  Password
                </label>
                <Link to="/forgot-password" className={`text-xs font-medium ${
                  isDarkMode
                    ? 'text-blue-400 hover:text-blue-300'
                    : 'text-indigo-600 hover:text-indigo-700'
                }`}>
                  Forgot Password?
                </Link>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 rounded-xl border transition-all duration-200 ${
                    isDarkMode
                      ? 'bg-gray-700/50 border-gray-600 focus:bg-gray-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-gray-100 placeholder:text-gray-500'
                      : 'bg-white/50 border-gray-200 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 text-gray-600 placeholder:text-gray-400'
                  }`}
                  placeholder="Enter your password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className={`absolute right-4 top-1/2 -translate-y-1/2 transition-colors duration-200 ${
                    isDarkMode
                      ? 'text-gray-400 hover:text-gray-300'
                      : 'text-gray-400 hover:text-gray-600'
                  }`}
                >
                  {showPassword ? <FaEyeSlash size={18} /> : <FaEye size={18} />}
                </button>
              </div>
            </div>

            {/* Login Button */}
            <button
              type="submit"
              disabled={loading}
              className={`w-full text-white mt-6 py-3.5 px-6 rounded-xl font-medium shadow-lg hover:shadow-xl focus:ring-2 focus:ring-offset-2 transition-all duration-200 hover:scale-[1.02] ${
                loading ? 'bg-indigo-400' : 'bg-indigo-600 hover:bg-indigo-700'
              }`}
            >
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          {/* Divider */}
          <div className="my-8 flex items-center">
            <div className={`flex-1 border-t ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}></div>
            <span className={`px-4 text-sm ${isDarkMode ? 'text-gray-500' : 'text-gray-500'}`}>
              or continue with
            </span>
            <div className={`flex-1 border-t ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}></div>
          </div>

          {/* Social Login */}
          <div className="grid grid-cols-2 gap-3 mb-6">
            <button className={`flex items-center justify-center gap-2 py-3 px-4 rounded-xl transition-all duration-200 ${
              isDarkMode
                ? 'bg-gray-700/50 border border-gray-600 hover:bg-gray-700 hover:shadow-md'
                : 'bg-white/80 backdrop-blur-sm border border-gray-200 hover:bg-white hover:shadow-md'
            }`}>
              <FaGoogle className="text-red-500" size={18} />
              <span className={`text-sm font-medium ${
                isDarkMode ? 'text-gray-300' : 'text-gray-700'
              }`}>Google</span>
            </button>
            <button className={`flex items-center justify-center gap-2 py-3 px-4 rounded-xl transition-all duration-200 ${
              isDarkMode
                ? 'bg-gray-700/50 border border-gray-600 hover:bg-gray-700 hover:shadow-md'
                : 'bg-white/80 backdrop-blur-sm border border-gray-200 hover:bg-white hover:shadow-md'
            }`}>
              <FaFacebook className="text-blue-600" size={18} />
              <span className={`text-sm font-medium ${
                isDarkMode ? 'text-gray-300' : 'text-gray-700'
              }`}>Facebook</span>
            </button>
          </div>

          {/* Sign Up Link */}
          <p className={`text-center text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            Don't have an account?{" "}
            <Link to="/signup" className={`font-medium ${
              isDarkMode
                ? 'bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-400 bg-clip-text text-transparent hover:opacity-80'
                : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent hover:opacity-80'
            }`}>
              Sign up for free
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default UserLogin; 