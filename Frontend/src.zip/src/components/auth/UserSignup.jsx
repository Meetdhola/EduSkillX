import React, { useState, useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FaEye, FaEyeSlash, FaSun, FaMoon } from 'react-icons/fa';
import { RiGraduationCapFill } from 'react-icons/ri';
import { useTheme } from '../../context/ThemeContext';
import { UserDataContext } from '../../context/userContext';
import ErrorPopup from '../ErrorPopup';
import axios from 'axios';

const UserSignup = () => {
    const { isDarkMode, toggleTheme } = useTheme();
    const { setUserData } = useContext(UserDataContext);
    const [showPassword, setShowPassword] = useState(false);
    const [error, setError] = useState('');
    const [formData, setFormData] = useState({
        Fullname: {
            firstname: '',
            lastname: ''
        },
        email: '',
        password: '',
        role: 'user', // Default role
        agreeToTerms: false
    });
        
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        
        if (type === 'checkbox') {
            setFormData(prev => ({
                ...prev,
                [name]: checked
            }));
        } else if (name === 'firstname' || name === 'lastname') {
            setFormData(prev => ({
                ...prev,
                Fullname: {
                    ...prev.Fullname,
                    [name]: value
                }
            }));
        } else {
            setFormData(prev => ({
                ...prev,
                [name]: value
            }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post(`${import.meta.env.VITE_BASE_URI}/auth/register`, formData);
            if (response.data) {
                setUserData(response.data);
                navigate('/dashboard');
            }
        } catch (error) {
            console.error('Signup error:', error);
            let errorMessage = 'An error occurred during signup. Please try again.';
            
            if (error.response) {
                // Handle specific error messages from the backend
                errorMessage = error.response.data.message || errorMessage;
            } else if (error.request) {
                // Handle network errors
                errorMessage = 'Network error. Please check your connection.';
            }
            
            setError(errorMessage);
            
            // Auto-dismiss error after 5 seconds
            setTimeout(() => {
                setError('');
            }, 5000);
        }
    };

    return (
        <div className={`min-h-screen flex items-center justify-center p-4 ${isDarkMode
                ? 'bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900'
                : 'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50'
            }`}>
            {/* Error Popup */}
            <ErrorPopup 
                error={error} 
                onClose={() => setError('')}
            />

            {/* Theme Toggle Button - Moved outside the card */}
            <button
                onClick={toggleTheme}
                className={`fixed top-4 right-4 p-3 rounded-full transition-all duration-300 z-50 ${isDarkMode
                        ? 'bg-gray-700 text-yellow-400 hover:bg-gray-600 shadow-lg'
                        : 'bg-white text-gray-800 hover:bg-gray-100 shadow-lg'
                    }`}
            >
                {isDarkMode ? <FaSun size={20} /> : <FaMoon size={20} />}
            </button>

            {!isDarkMode && (
                <>
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-indigo-100/40 via-transparent to-transparent"></div>
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,_var(--tw-gradient-stops))] from-blue-100/40 via-transparent to-transparent"></div>
                </>
            )}

            <div className="w-full max-w-[400px] relative">
                {/* Left side decorative element */}
                <div className={`absolute -left-6 top-1/2 -translate-y-1/2 w-1 h-32 rounded-full ${isDarkMode
                        ? 'bg-gradient-to-b from-blue-500 via-indigo-500 to-purple-500'
                        : 'bg-gradient-to-b from-blue-600 via-indigo-600 to-purple-600'
                    }`}></div>

                <div className={`backdrop-blur-sm rounded-2xl p-10 ${isDarkMode
                        ? 'bg-gray-800/50 shadow-[0_20px_50px_rgba(0,_0,_0,_0.3)] border border-gray-700'
                        : 'bg-white/70 shadow-[0_20px_50px_rgba(8,_112,_184,_0.07)] border border-white/50'
                    }`}>
                    {/* Logo and Title */}
                    <div className="text-center mb-8">
                        <div className="flex items-center justify-center mb-6">
                            <div className={`p-3 rounded-2xl shadow-lg transform hover:scale-105 transition-transform duration-300 ${isDarkMode
                                    ? 'bg-gradient-to-br from-blue-500 via-indigo-500 to-purple-500'
                                    : 'bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600'
                                }`}>
                                <RiGraduationCapFill className="text-4xl text-white" />
                            </div>
                        </div>
                        <h1 className={`text-2xl font-semibold mb-2 ${isDarkMode
                                ? 'bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-400 bg-clip-text text-transparent'
                                : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent'
                            }`}>Create Account</h1>
                        <p className={isDarkMode ? 'text-gray-400 text-sm' : 'text-gray-600 text-sm'}>
                            Join our learning community today
                        </p>
                    </div>

                    {/* Signup Form */}
                    <form onSubmit={handleSubmit} className="space-y-5">
                        {/* First Name Input */}
                        <div>
                            <label className={`block text-sm font-medium mb-1.5 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                                First Name
                            </label>
                            <input
                                type="text"
                                name="firstname"
                                value={formData.Fullname.firstname}
                                onChange={handleChange}
                                className={`w-full px-4 py-3 rounded-xl border transition-all duration-200 ${isDarkMode
                                    ? 'bg-gray-700/50 border-gray-600 focus:bg-gray-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-gray-100 placeholder:text-gray-500'
                                    : 'bg-white/50 border-gray-200 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 text-gray-600 placeholder:text-gray-400'
                                }`}
                                placeholder="Enter your first name"
                                required
                                minLength={3}
                            />
                        </div>

                        {/* Last Name Input */}
                        <div>
                            <label className={`block text-sm font-medium mb-1.5 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                                Last Name
                            </label>
                            <input
                                type="text"
                                name="lastname"
                                value={formData.Fullname.lastname}
                                onChange={handleChange}
                                className={`w-full px-4 py-3 rounded-xl border transition-all duration-200 ${isDarkMode
                                    ? 'bg-gray-700/50 border-gray-600 focus:bg-gray-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-gray-100 placeholder:text-gray-500'
                                    : 'bg-white/50 border-gray-200 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 text-gray-600 placeholder:text-gray-400'
                                }`}
                                placeholder="Enter your last name"
                                required
                                minLength={3}
                            />
                        </div>

                        {/* Email Input */}
                        <div>
                            <label className={`block text-sm font-medium mb-1.5 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                                Email address
                            </label>
                            <input
                                type="email"
                                name="email"
                                value={formData.email}
                                onChange={handleChange}
                                className={`w-full px-4 py-3 rounded-xl border transition-all duration-200 ${isDarkMode
                                    ? 'bg-gray-700/50 border-gray-600 focus:bg-gray-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-gray-100 placeholder:text-gray-500'
                                    : 'bg-white/50 border-gray-200 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 text-gray-600 placeholder:text-gray-400'
                                }`}
                                placeholder="Enter your email"
                                required
                            />
                        </div>

                        {/* Password Input */}
                        <div>
                            <label className={`block text-sm font-medium mb-1.5 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                                Password
                            </label>
                            <div className="relative">
                                <input
                                    type={showPassword ? "text" : "password"}
                                    name="password"
                                    value={formData.password}
                                    onChange={handleChange}
                                    className={`w-full px-4 py-3 rounded-xl border transition-all duration-200 ${isDarkMode
                                        ? 'bg-gray-700/50 border-gray-600 focus:bg-gray-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-gray-100 placeholder:text-gray-500'
                                        : 'bg-white/50 border-gray-200 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 text-gray-600 placeholder:text-gray-400'
                                    }`}
                                    placeholder="Create a password"
                                    required
                                    minLength={6}
                                />
                                <button
                                    type="button"
                                    onClick={() => setShowPassword(!showPassword)}
                                    className={`absolute right-4 top-1/2 -translate-y-1/2 transition-colors duration-200 ${isDarkMode
                                        ? 'text-gray-400 hover:text-gray-300'
                                        : 'text-gray-400 hover:text-gray-600'
                                    }`}
                                >
                                    {showPassword ? <FaEyeSlash size={18} /> : <FaEye size={18} />}
                                </button>
                            </div>
                        </div>

                        {/* Role Selection Dropdown */}
                        <div>
                            <label className={`block text-sm font-medium mb-1.5 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                                Select Role
                            </label>
                            <select
                                name="role"
                                value={formData.role}
                                onChange={handleChange}
                                className={`w-full px-4 py-3 rounded-xl border transition-all duration-200 appearance-none bg-no-repeat bg-right ${isDarkMode
                                    ? 'bg-gray-700/50 border-gray-600 focus:bg-gray-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-gray-100'
                                    : 'bg-white/50 border-gray-200 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 text-gray-600'
                                }`}
                                required
                                style={{
                                    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='${isDarkMode ? '%23718096' : '%234A5568'}'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E")`,
                                    backgroundSize: '1.5em',
                                    paddingRight: '2.5rem'
                                }}
                            >
                                <option value="user">User</option>
                                <option value="tutor">Tutor</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>

                        {/* Terms and Conditions */}
                        <div className="flex items-start space-x-3 mt-2">
                            <input
                                type="checkbox"
                                name="agreeToTerms"
                                checked={formData.agreeToTerms}
                                onChange={handleChange}
                                className={`mt-0.5 h-4 w-4 rounded border transition-colors duration-200 ${isDarkMode
                                        ? 'border-gray-600 bg-gray-700/50 text-blue-500 focus:ring-blue-500 focus:ring-offset-gray-900'
                                        : 'border-gray-300 text-indigo-600 focus:ring-indigo-500'
                                    }`}
                                required
                            />
                            <label className={isDarkMode ? 'text-gray-400 text-sm' : 'text-gray-600 text-sm'}>
                                I agree to the{" "}
                                <Link to="/terms" className={`font-medium ${isDarkMode
                                        ? 'bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-400 bg-clip-text text-transparent hover:opacity-80'
                                        : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent hover:opacity-80'
                                    }`}>
                                    Terms & Conditions
                                </Link>
                                {" "}and{" "}
                                <Link to="/privacy" className={`font-medium ${isDarkMode
                                        ? 'bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-400 bg-clip-text text-transparent hover:opacity-80'
                                        : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent hover:opacity-80'
                                    }`}>
                                    Privacy Policy
                                </Link>
                            </label>
                        </div>

                        {/* Signup Button */}
                        <button
                            type="submit"
                            className={`w-full text-white mt-6 py-3.5 px-6 rounded-xl font-medium shadow-lg hover:shadow-xl focus:ring-2 focus:ring-offset-2 transition-all duration-200 hover:scale-[1.02] ${isDarkMode
                                    ? 'bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 focus:ring-blue-500'
                                    : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 focus:ring-indigo-500'
                                }`}
                        >
                            Create Account
                        </button>
                    </form>

                    {/* Login Link */}
                    <p className={`text-center text-sm mt-6 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                        Already have an account?{" "}
                        <Link to="/login" className={`font-medium ${isDarkMode
                                ? 'bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-400 bg-clip-text text-transparent hover:opacity-80'
                                : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent hover:opacity-80'
                            }`}>
                            Sign in here
                        </Link>
                    </p>
                </div>
            </div>
        </div>
    );
};

export default UserSignup; 