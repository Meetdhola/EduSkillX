import React from 'react';
import './CourseVerfication.css';

// Icons
const VRIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M21 7H3C1.9 7 1 7.9 1 9V15C1 16.1 1.9 17 3 17H7L9 19H15L17 17H21C22.1 17 23 16.1 23 15V9C23 7.9 22.1 7 21 7ZM7.25 14.25C5.75 14.25 4.5 13 4.5 11.5C4.5 10 5.75 8.75 7.25 8.75C8.75 8.75 10 10 10 11.5C10 13 8.75 14.25 7.25 14.25ZM16.75 14.25C15.25 14.25 14 13 14 11.5C14 10 15.25 8.75 16.75 8.75C18.25 8.75 19.5 10 19.5 11.5C19.5 13 18.25 14.25 16.75 14.25Z" />
  </svg>
);

const SkillBarterIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M19 8L15 12H18C18 15.31 15.31 18 12 18C10.99 18 10.03 17.75 9.2 17.3L7.74 18.76C8.97 19.54 10.43 20 12 20C16.42 20 20 16.42 20 12H23L19 8ZM6 12C6 8.69 8.69 6 12 6C13.01 6 13.97 6.25 14.8 6.7L16.26 5.24C15.03 4.46 13.57 4 12 4C7.58 4 4 7.58 4 12H1L5 16L9 12H6Z" />
  </svg>
);

const AITutorIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 9V7C20 5.9 19.1 5 18 5H16V3C16 1.9 15.1 1 14 1H10C8.9 1 8 1.9 8 3V5H6C4.9 5 4 5.9 4 7V9C2.9 9 2 9.9 2 11V14H3V21C3 21.6 3.4 22 4 22H20C20.6 22 21 21.6 21 21V14H22V11C22 9.9 21.1 9 20 9ZM14 3H10V5H14V3ZM6 7H18V9H6V7ZM19 20H5V14H19V20ZM20 12H4V11H20V12Z" />
  </svg>
);

const EduSkillX = () => {
  return (
    <div className="edu-skillx">
      <header className="header">
        <div className="logo">EduSkillX</div>
        <nav className="navigation">
          <ul>
            <li><a href="#home">Home</a></li>
            <li><a href="#courses">Courses</a></li>
            <li><a href="#marketplace">Marketplace</a></li>
            <li><a href="#ai-tutor">AI Tutor</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
        </nav>
        <div className="auth-buttons">
          <button className="login-btn">Login</button>
          <button className="signup-btn">Sign Up</button>
        </div>
      </header>

      <section className="hero">
        <div className="hero-content">
          <h1>Transform your learning journey with cutting-edge AR/VR technology and AI-powered tutoring. Exchange skills, earn certifications, and evolve your career.</h1>
          <div className="hero-buttons">
            <button className="get-started-btn">Get Started</button>
            <button className="explore-btn">Explore Courses</button>
          </div>
        </div>
      </section>

      <section className="features">
        <h2>Revolutionary Learning Features</h2>
        <div className="feature-cards">
          <div className="feature-card">
            <div className="feature-icon">
              <VRIcon />
            </div>
            <h3>AR/VR Learning</h3>
            <p>Immerse yourself in interactive 3D environments for enhanced learning experiences.</p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">
              <SkillBarterIcon />
            </div>
            <h3>Skill Barter</h3>
            <p>Exchange knowledge and skills with peers in our innovative marketplace.</p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">
              <AITutorIcon />
            </div>
            <h3>AI Tutor</h3>
            <p>Get personalized learning assistance powered by advanced AI technology.</p>
          </div>
        </div>
      </section>

      <footer className="footer">
        <div className="footer-top">
          <div className="footer-logo-section">
            <div className="footer-logo">EduSkillX</div>
            <p>Transform your learning journey with cutting-edge technology and personalized education.</p>
            <div className="social-links">
              <a href="#twitter" aria-label="Twitter"><i className="icon-twitter"></i></a>
              <a href="#facebook" aria-label="Facebook"><i className="icon-facebook"></i></a>
              <a href="#instagram" aria-label="Instagram"><i className="icon-instagram"></i></a>
              <a href="#linkedin" aria-label="LinkedIn"><i className="icon-linkedin"></i></a>
            </div>
          </div>

          <div className="newsletter">
            <h3>Subscribe to Our Newsletter</h3>
            <div className="subscribe-form">
              <input type="email" placeholder="Enter your email" aria-label="Email for newsletter" />
              <button className="subscribe-btn">Subscribe</button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default EduSkillX;