import React from 'react';
import { FaGraduationCap, FaHome, FaBook, FaList, FaUsers, FaTrophy } from 'react-icons/fa';
import { IoMdNotifications } from 'react-icons/io';
import { RiVipDiamondFill } from 'react-icons/ri';
import { BsVr } from 'react-icons/bs';

const Dashboard = () => {
  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="w-16 bg-white flex flex-col items-center py-6 space-y-8">
        <div className="text-blue-600">
          <FaGraduationCap size={24} />
        </div>
        <div className="flex flex-col space-y-8">
          <FaHome size={20} className="text-gray-400 hover:text-blue-600 cursor-pointer" />
          <FaBook size={20} className="text-gray-400 hover:text-blue-600 cursor-pointer" />
          <FaList size={20} className="text-gray-400 hover:text-blue-600 cursor-pointer" />
          <FaUsers size={20} className="text-gray-400 hover:text-blue-600 cursor-pointer" />
          <FaTrophy size={20} className="text-gray-400 hover:text-blue-600 cursor-pointer" />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-6 bg-light">
        {/* Top Navigation */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex space-x-6">
            <button className="font-semibold text-blue-600 border-b-2 border-blue-600 pb-1">Dashboard</button>
            <button className="text-gray-500 hover:text-blue-600">Courses</button>
            <button className="text-gray-500 hover:text-blue-600">Marketplace</button>
            <button className="text-gray-500 hover:text-blue-600">AI Tutor</button>
            <button className="text-gray-500 hover:text-blue-600">Rewards</button>
          </div>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <IoMdNotifications size={24} className="text-gray-500" />
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
                <span className="text-white text-xs">2</span>
              </div>
            </div>
            <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="Profile" className="w-10 h-10 rounded-full" />
          </div>
        </div>

        {/* User Profile Summary */}
        <div className="flex items-center justify-between bg-white rounded-lg p-4 mb-6">
          <div className="flex items-center">
            <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="Profile" className="w-12 h-12 rounded-full mr-4" />
            <div>
              <h2 className="font-bold text-lg">Sarah Johnson</h2>
              <p className="text-gray-500 text-sm">Frontend Development Path</p>
            </div>
          </div>
          <div className="flex items-center space-x-8">
            <div className="text-center">
              <p className="font-bold text-blue-600 text-xl">85%</p>
              <p className="text-xs text-gray-500">Progress</p>
            </div>
            <div className="text-center">
              <p className="font-bold text-purple-600 text-xl">12</p>
              <p className="text-xs text-gray-500">Courses</p>
            </div>
            <div className="text-center">
              <p className="font-bold text-green-600 text-xl">1,250</p>
              <p className="text-xs text-gray-500">Points</p>
            </div>
          </div>
        </div>

        {/* Course Progress */}
        <div className="grid grid-cols-3 gap-6 mb-6">
          <CourseCard 
            title="Advanced React Patterns" 
            category="Frontend Development" 
            progress={75} 
            progressColor="bg-blue-500" 
          />
          <CourseCard 
            title="UI/UX Fundamentals" 
            category="Design" 
            progress={45} 
            progressColor="bg-purple-500" 
          />
          <CourseCard 
            title="Node.js Masterclass" 
            category="Backend Development" 
            progress={90} 
            progressColor="bg-green-500" 
          />
        </div>

        {/* Learning Options */}
        <div className="grid grid-cols-2 gap-6 mb-6">
          <button className="bg-blue-500 text-white py-3 rounded-lg flex items-center justify-center space-x-2">
            <span className="bg-blue-600 p-1 rounded">
              <RiVipDiamondFill size={20} />
            </span>
            <span className="font-semibold">Start AR Learning</span>
          </button>
          <button className="bg-purple-500 text-white py-3 rounded-lg flex items-center justify-center space-x-2">
            <span className="bg-purple-600 p-1 rounded">
              <BsVr size={20} />
            </span>
            <span className="font-semibold">Enter VR Mode</span>
          </button>
        </div>

        {/* Achievements and Leaderboard */}
        <div className="grid grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg">
            <h3 className="font-semibold text-lg mb-4">Recent Achievements</h3>
            <div className="flex space-x-4">
              <div className="bg-blue-100 w-12 h-12 rounded-lg flex items-center justify-center">
                <FaTrophy className="text-blue-500" size={20} />
              </div>
              <div className="bg-gray-100 w-12 h-12 rounded-lg flex items-center justify-center">
                <RiVipDiamondFill className="text-gray-500" size={20} />
              </div>
              <div className="bg-green-100 w-12 h-12 rounded-lg flex items-center justify-center">
                <FaTrophy className="text-green-500" size={20} />
              </div>
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-lg">
            <h3 className="font-semibold text-lg mb-4">Leaderboard</h3>
            <div className="space-y-4">
              <LeaderboardItem position={1} name="Alex M." points={2450} />
              <LeaderboardItem position={2} name="Emma R." points={2290} />
              <LeaderboardItem position={3} name="John D." points={2180} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Course Card Component
const CourseCard = ({ title, category, progress, progressColor }) => {
  return (
    <div className="bg-white p-4 rounded-lg">
      <div className="mb-2">
        <h3 className="font-semibold">{title}</h3>
        <p className="text-gray-500 text-sm">{category}</p>
      </div>
      <div className="relative h-2 bg-gray-200 rounded-full">
        <div 
          className={`absolute top-0 left-0 h-2 rounded-full ${progressColor}`} 
          style={{ width: `${progress}%` }}
        ></div>
      </div>
      <div className="text-right mt-1">
        <span className="text-xs text-gray-500">{progress}%</span>
      </div>
    </div>
  );
};

// Leaderboard Item Component
const LeaderboardItem = ({ position, name, points }) => {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center">
        <span className="text-gray-500 mr-2">{position}</span>
        <div className="flex items-center">
          <img src={`https://randomuser.me/api/portraits/men/${position + 20}.jpg`} alt={name} className="w-8 h-8 rounded-full mr-2" />
          <span>{name}</span>
        </div>
      </div>
      <div className="font-semibold">{points} pts</div>
    </div>
  );
};

export default Dashboard;
