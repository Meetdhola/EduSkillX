import React from 'react';
import './EduSkillx.css';

// Simple icon component instead of using react-icons
const Icon = ({ name }) => {
  // Basic icons using HTML entities or simple characters
  const icons = {
    graduation: '🎓',
    search: '🔍',
    twitter: '𝕏',
    facebook: 'f',
    instagram: '📷',
    linkedin: 'in',
    star: '★',
    menu: '≡'
  };

  return <span className="icon">{icons[name] || '•'}</span>;
};

const EduSkillx = () => {
  return (
    <div className="eduskillx-container">
      <header className="header">
        <div className="logo-container">
          <Icon name="graduation" />
          <h1 className="logo-text">EduSkillx</h1>
        </div>
        <nav className="main-nav">
          <ul className="nav-links">
            <li><a href="#home">Home</a></li>
            <li><a href="#browse">Browse Skills</a></li>
            <li><a href="#live">Live Sessions</a></li>
            <li><a href="#about">About</a></li>
          </ul>
        </nav>
        <button className="sign-in-btn">Sign in</button>
      </header>

      <div className="search-section">
        <div className="search-container">
          <input type="text" placeholder="Search skills..." className="search-input" />
          <button className="search-btn">
            <Icon name="search" />
          </button>
        </div>
        <div className="category-filter">
          <select className="category-select">
            <option>All Categories</option>
          </select>
        </div>
        <button className="filter-btn">
          <Icon name="menu" />
        </button>
      </div>

      <div className="profiles-section">
        <div className="profile-card">
          <div className="profile-header">
            <div className="profile-img-placeholder">AM</div>
            <div className="profile-status online">Online</div>
            <h3 className="profile-name">Alex Morgan</h3>
            <p className="profile-verification">Verified on Blockchain</p>
          </div>
          <div className="profile-content">
            <div className="offering">
              <p className="label">Offering</p>
              <p className="value">Advanced Python Programming</p>
            </div>
            <div className="looking-for">
              <p className="label">Looking for</p>
              <p className="value">UI/UX Design Basics</p>
            </div>
            <button className="barter-btn">Barter Now</button>
          </div>
        </div>

        <div className="profile-card">
          <div className="profile-header">
            <div className="profile-img-placeholder">SC</div>
            <div className="profile-status online">Online</div>
            <h3 className="profile-name">Sarah Chen</h3>
            <p className="profile-verification">Verified on Blockchain</p>
          </div>
          <div className="profile-content">
            <div className="offering">
              <p className="label">Offering</p>
              <p className="value">Digital Illustration</p>
            </div>
            <div className="looking-for">
              <p className="label">Looking for</p>
              <p className="value">Spanish Language</p>
            </div>
            <button className="barter-btn">Barter Now</button>
          </div>
        </div>

        <div className="profile-card">
          <div className="profile-header">
            <div className="profile-img-placeholder">MW</div>
            <div className="profile-status away">Away</div>
            <h3 className="profile-name">Mike Wilson</h3>
            <p className="profile-verification">Verified on Blockchain</p>
          </div>
          <div className="profile-content">
            <div className="offering">
              <p className="label">Offering</p>
              <p className="value">French Language</p>
            </div>
            <div className="looking-for">
              <p className="label">Looking for</p>
              <p className="value">Web Development</p>
            </div>
            <button className="barter-btn">Barter Now</button>
          </div>
        </div>
      </div>

      <div className="barter-sessions-section">
        <h2 className="section-title">Live Barter Sessions</h2>
        <div className="session-card">
          <div className="session-info">
            <div className="session-img-placeholder">DW</div>
            <div className="session-details">
              <h3 className="session-title">Design Workshop</h3>
              <p className="participants">12 Participants</p>
            </div>
          </div>
          <button className="join-session-btn">Join Live Barter</button>
        </div>
      </div>

      <div className="reviews-section">
        <h2 className="section-title">Recent Reviews</h2>
        <div className="review-card">
          <div className="reviewer-info">
            <div className="reviewer-img-placeholder">JB</div>
            <h3 className="reviewer-name">James Brown</h3>
            <div className="rating">
              <span className="star"><Icon name="star" /></span>
              <span className="star"><Icon name="star" /></span>
              <span className="star"><Icon name="star" /></span>
              <span className="star"><Icon name="star" /></span>
              <span className="star"><Icon name="star" /></span>
            </div>
          </div>
          <p className="review-text">
            Amazing experience learning Python! The instructor was very knowledgeable and patient.
          </p>
        </div>
      </div>

      <footer className="footer">
        <div className="footer-top">
          <div className="footer-brand">
            <div className="logo-container">
              <Icon name="graduation" />
              <h2 className="logo-text">EduSkillx</h2>
            </div>
            <p className="tagline">Exchange skills, grow together.</p>
          </div>

          <div className="footer-links">
            <div className="footer-column">
              <h3 className="footer-heading">Quick Links</h3>
              <ul>
                <li><a href="#about-us">About Us</a></li>
                <li><a href="#how-it-works">How It Works</a></li>
                <li><a href="#security">Security</a></li>
              </ul>
            </div>

            <div className="footer-column">
              <h3 className="footer-heading">Support</h3>
              <ul>
                <li><a href="#help">Help Center</a></li>
                <li><a href="#terms">Terms of Service</a></li>
                <li><a href="#privacy">Privacy Policy</a></li>
              </ul>
            </div>

            <div className="footer-column">
              <h3 className="footer-heading">Connect</h3>
              <div className="social-icons">
                <a href="#twitter" className="social-icon"><Icon name="twitter" /></a>
                <a href="#facebook" className="social-icon"><Icon name="facebook" /></a>
                <a href="#instagram" className="social-icon"><Icon name="instagram" /></a>
                <a href="#linkedin" className="social-icon"><Icon name="linkedin" /></a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default EduSkillx;