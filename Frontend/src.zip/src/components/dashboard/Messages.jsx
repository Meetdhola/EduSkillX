import React, { useState, useEffect } from 'react';
import { FaPaperPlane, FaSearch, FaUserCircle, FaClock } from 'react-icons/fa';
import { useTheme } from '../../context/ThemeContext';
import axios from 'axios';

const Messages = () => {
    const { isDarkMode } = useTheme();
    const [conversations, setConversations] = useState([]);
    const [selectedConversation, setSelectedConversation] = useState(null);
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');
    const [searchQuery, setSearchQuery] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [userRole, setUserRole] = useState(null);

    useEffect(() => {
        const user = JSON.parse(localStorage.getItem('user'));
        setUserRole(user?.role);
        fetchConversations();
    }, []);

    useEffect(() => {
        if (selectedConversation) {
            fetchMessages(selectedConversation._id);
        }
    }, [selectedConversation]);

    const fetchConversations = async () => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get(`${import.meta.env.VITE_BASE_URI}/messages/conversations`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            setConversations(response.data.conversations);
        } catch (error) {
            console.error('Error fetching conversations:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const fetchMessages = async (conversationId) => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get(
                `${import.meta.env.VITE_BASE_URI}/messages/${conversationId}`,
                {
                    headers: { Authorization: `Bearer ${token}` }
                }
            );
            setMessages(response.data.messages);
        } catch (error) {
            console.error('Error fetching messages:', error);
        }
    };

    const sendMessage = async (e) => {
        e.preventDefault();
        if (!newMessage.trim() || !selectedConversation) return;

        try {
            const token = localStorage.getItem('token');
            await axios.post(
                `${import.meta.env.VITE_BASE_URI}/messages/${selectedConversation._id}`,
                { content: newMessage },
                {
                    headers: { Authorization: `Bearer ${token}` }
                }
            );
            setNewMessage('');
            fetchMessages(selectedConversation._id);
        } catch (error) {
            console.error('Error sending message:', error);
        }
    };

    const filteredConversations = conversations.filter(conv => {
        const searchTerm = searchQuery.toLowerCase();
        return (
            conv.participant.Fullname.firstname.toLowerCase().includes(searchTerm) ||
            conv.participant.Fullname.lastname.toLowerCase().includes(searchTerm) ||
            conv.participant.email.toLowerCase().includes(searchTerm)
        );
    });

    if (isLoading) {
        return (
            <div className="flex justify-center items-center h-full">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
            </div>
        );
    }

    return (
        <div className="flex h-full">
            {/* Conversations List */}
            <div className={`w-1/3 border-r ${
                isDarkMode ? 'border-gray-700 bg-gray-800' : 'border-gray-200 bg-white'
            }`}>
                <div className="p-4 border-b border-gray-200">
                    <div className={`flex items-center px-4 py-2 rounded-lg ${
                        isDarkMode ? 'bg-gray-700' : 'bg-gray-100'
                    }`}>
                        <FaSearch className={isDarkMode ? 'text-gray-400' : 'text-gray-500'} />
                        <input
                            type="text"
                            placeholder="Search conversations..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className={`ml-2 w-full bg-transparent border-none focus:outline-none ${
                                isDarkMode ? 'text-gray-100 placeholder-gray-500' : 'text-gray-800 placeholder-gray-400'
                            }`}
                        />
                    </div>
                </div>
                <div className="overflow-y-auto h-[calc(100vh-5rem)]">
                    {filteredConversations.map((conversation) => (
                        <div
                            key={conversation._id}
                            onClick={() => setSelectedConversation(conversation)}
                            className={`p-4 cursor-pointer hover:bg-gray-100 ${
                                selectedConversation?._id === conversation._id
                                    ? isDarkMode
                                        ? 'bg-gray-700'
                                        : 'bg-gray-100'
                                    : ''
                            }`}
                        >
                            <div className="flex items-center">
                                <FaUserCircle className="text-2xl mr-3 text-gray-500" />
                                <div>
                                    <h3 className="font-medium">
                                        {conversation.participant.Fullname.firstname} {conversation.participant.Fullname.lastname}
                                    </h3>
                                    <p className={`text-sm ${
                                        isDarkMode ? 'text-gray-400' : 'text-gray-500'
                                    }`}>
                                        {conversation.participant.email}
                                    </p>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 flex flex-col">
                {selectedConversation ? (
                    <>
                        {/* Messages Header */}
                        <div className={`p-4 border-b ${
                            isDarkMode ? 'border-gray-700 bg-gray-800' : 'border-gray-200 bg-white'
                        }`}>
                            <div className="flex items-center">
                                <FaUserCircle className="text-2xl mr-3 text-gray-500" />
                                <div>
                                    <h3 className="font-medium">
                                        {selectedConversation.participant.Fullname.firstname} {selectedConversation.participant.Fullname.lastname}
                                    </h3>
                                    <p className={`text-sm ${
                                        isDarkMode ? 'text-gray-400' : 'text-gray-500'
                                    }`}>
                                        {selectedConversation.participant.email}
                                    </p>
                                </div>
                            </div>
                        </div>

                        {/* Messages List */}
                        <div className="flex-1 overflow-y-auto p-4 space-y-4">
                            {messages.map((message) => (
                                <div
                                    key={message._id}
                                    className={`flex ${
                                        message.sender._id === userRole ? 'justify-end' : 'justify-start'
                                    }`}
                                >
                                    <div className={`max-w-[70%] rounded-lg p-3 ${
                                        message.sender._id === userRole
                                            ? isDarkMode
                                                ? 'bg-blue-600 text-white'
                                                : 'bg-blue-500 text-white'
                                            : isDarkMode
                                                ? 'bg-gray-700 text-gray-100'
                                                : 'bg-gray-100 text-gray-800'
                                    }`}>
                                        <p>{message.content}</p>
                                        <div className={`text-xs mt-1 flex items-center ${
                                            message.sender._id === userRole
                                                ? 'text-blue-100'
                                                : isDarkMode
                                                    ? 'text-gray-400'
                                                    : 'text-gray-500'
                                        }`}>
                                            <FaClock className="mr-1" />
                                            {new Date(message.createdAt).toLocaleTimeString()}
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>

                        {/* Message Input */}
                        <form onSubmit={sendMessage} className={`p-4 border-t ${
                            isDarkMode ? 'border-gray-700 bg-gray-800' : 'border-gray-200 bg-white'
                        }`}>
                            <div className="flex items-center space-x-4">
                                <input
                                    type="text"
                                    value={newMessage}
                                    onChange={(e) => setNewMessage(e.target.value)}
                                    placeholder="Type a message..."
                                    className={`flex-1 px-4 py-2 rounded-lg border ${
                                        isDarkMode
                                            ? 'bg-gray-700 border-gray-600 text-white'
                                            : 'bg-white border-gray-300'
                                    }`}
                                />
                                <button
                                    type="submit"
                                    className={`p-2 rounded-lg ${
                                        isDarkMode
                                            ? 'bg-blue-600 hover:bg-blue-700'
                                            : 'bg-blue-500 hover:bg-blue-600'
                                    } text-white`}
                                >
                                    <FaPaperPlane />
                                </button>
                            </div>
                        </form>
                    </>
                ) : (
                    <div className="flex-1 flex items-center justify-center">
                        <p className={`text-lg ${
                            isDarkMode ? 'text-gray-400' : 'text-gray-500'
                        }`}>
                            Select a conversation to start messaging
                        </p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Messages; 