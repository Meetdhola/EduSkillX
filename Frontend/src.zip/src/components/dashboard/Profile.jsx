import React, { useState, useEffect } from 'react';
import { FaUser, FaEnvelope, FaCalendar, FaMapMarker } from 'react-icons/fa';
import { useTheme } from '../../context/ThemeContext';
import axios from 'axios';

const Profile = () => {
    const { isDarkMode } = useTheme();
    const [userData, setUserData] = useState(null);
    const [isEditing, setIsEditing] = useState(false);
    const [formData, setFormData] = useState({
        Fullname: {
            firstname: '',
            lastname: ''
        },
        email: '',
        bio: '',
        location: '',
        joinDate: ''
    });

    useEffect(() => {
        const fetchUserData = async () => {
            try {
                const token = localStorage.getItem('token');
                const user = JSON.parse(localStorage.getItem('user'));
                const response = await axios.get(`${import.meta.env.VITE_BASE_URI}/user/${user._id}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setUserData(response.data.user);
                setFormData({
                    Fullname: response.data.user.Fullname,
                    email: response.data.user.email,
                    bio: response.data.user.bio || '',
                    location: response.data.user.location || '',
                    joinDate: new Date(response.data.user.createdAt).toLocaleDateString()
                });
            } catch (error) {
                console.error('Error fetching user data:', error);
            }
        };

        fetchUserData();
    }, []);

    const handleChange = (e) => {
        const { name, value } = e.target;
        if (name === 'firstname' || name === 'lastname') {
            setFormData(prev => ({
                ...prev,
                Fullname: {
                    ...prev.Fullname,
                    [name]: value
                }
            }));
        } else {
            setFormData(prev => ({
                ...prev,
                [name]: value
            }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem('token');
            const response = await axios.put(
                `${import.meta.env.VITE_BASE_URI}/user/update`,
                formData,
                { headers: { Authorization: `Bearer ${token}` } }
            );
            setUserData(response.data.user);
            setIsEditing(false);
        } catch (error) {
            console.error('Error updating profile:', error);
        }
    };

    if (!userData) {
        return (
            <div className="flex justify-center items-center h-full">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
            </div>
        );
    }

    return (
        <div className="p-6">
            <div className="max-w-4xl mx-auto">
                <div className={`rounded-2xl p-6 ${isDarkMode ? 'bg-gray-800' : 'bg-white'} shadow-lg`}>
                    {/* Profile Header */}
                    <div className="flex items-center space-x-6 mb-8">
                        <div className={`w-24 h-24 rounded-full flex items-center justify-center ${
                            isDarkMode ? 'bg-gray-700' : 'bg-gray-100'
                        }`}>
                            <FaUser className="text-4xl text-gray-400" />
                        </div>
                        <div>
                            <h1 className="text-2xl font-bold">
                                {userData.Fullname.firstname} {userData.Fullname.lastname}
                            </h1>
                            <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                                {userData.role.charAt(0).toUpperCase() + userData.role.slice(1)}
                            </p>
                        </div>
                    </div>

                    {/* Profile Form */}
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {/* First Name */}
                            <div>
                                <label className={`block text-sm font-medium mb-2 ${
                                    isDarkMode ? 'text-gray-300' : 'text-gray-700'
                                }`}>
                                    First Name
                                </label>
                                <input
                                    type="text"
                                    name="firstname"
                                    value={formData.Fullname.firstname}
                                    onChange={handleChange}
                                    disabled={!isEditing}
                                    className={`w-full px-4 py-2 rounded-lg border ${
                                        isDarkMode
                                            ? 'bg-gray-700 border-gray-600 text-gray-100'
                                            : 'bg-white border-gray-300 text-gray-900'
                                    }`}
                                />
                            </div>

                            {/* Last Name */}
                            <div>
                                <label className={`block text-sm font-medium mb-2 ${
                                    isDarkMode ? 'text-gray-300' : 'text-gray-700'
                                }`}>
                                    Last Name
                                </label>
                                <input
                                    type="text"
                                    name="lastname"
                                    value={formData.Fullname.lastname}
                                    onChange={handleChange}
                                    disabled={!isEditing}
                                    className={`w-full px-4 py-2 rounded-lg border ${
                                        isDarkMode
                                            ? 'bg-gray-700 border-gray-600 text-gray-100'
                                            : 'bg-white border-gray-300 text-gray-900'
                                    }`}
                                />
                            </div>

                            {/* Email */}
                            <div>
                                <label className={`block text-sm font-medium mb-2 ${
                                    isDarkMode ? 'text-gray-300' : 'text-gray-700'
                                }`}>
                                    Email
                                </label>
                                <div className="relative">
                                    <FaEnvelope className={`absolute left-3 top-1/2 transform -translate-y-1/2 ${
                                        isDarkMode ? 'text-gray-400' : 'text-gray-500'
                                    }`} />
                                    <input
                                        type="email"
                                        name="email"
                                        value={formData.email}
                                        onChange={handleChange}
                                        disabled={!isEditing}
                                        className={`w-full pl-10 pr-4 py-2 rounded-lg border ${
                                            isDarkMode
                                                ? 'bg-gray-700 border-gray-600 text-gray-100'
                                                : 'bg-white border-gray-300 text-gray-900'
                                        }`}
                                    />
                                </div>
                            </div>

                            {/* Location */}
                            <div>
                                <label className={`block text-sm font-medium mb-2 ${
                                    isDarkMode ? 'text-gray-300' : 'text-gray-700'
                                }`}>
                                    Location
                                </label>
                                <div className="relative">
                                    <FaMapMarker className={`absolute left-3 top-1/2 transform -translate-y-1/2 ${
                                        isDarkMode ? 'text-gray-400' : 'text-gray-500'
                                    }`} />
                                    <input
                                        type="text"
                                        name="location"
                                        value={formData.location}
                                        onChange={handleChange}
                                        disabled={!isEditing}
                                        className={`w-full pl-10 pr-4 py-2 rounded-lg border ${
                                            isDarkMode
                                                ? 'bg-gray-700 border-gray-600 text-gray-100'
                                                : 'bg-white border-gray-300 text-gray-900'
                                        }`}
                                    />
                                </div>
                            </div>

                            {/* Join Date */}
                            <div>
                                <label className={`block text-sm font-medium mb-2 ${
                                    isDarkMode ? 'text-gray-300' : 'text-gray-700'
                                }`}>
                                    Join Date
                                </label>
                                <div className="relative">
                                    <FaCalendar className={`absolute left-3 top-1/2 transform -translate-y-1/2 ${
                                        isDarkMode ? 'text-gray-400' : 'text-gray-500'
                                    }`} />
                                    <input
                                        type="text"
                                        value={formData.joinDate}
                                        disabled
                                        className={`w-full pl-10 pr-4 py-2 rounded-lg border ${
                                            isDarkMode
                                                ? 'bg-gray-700 border-gray-600 text-gray-100'
                                                : 'bg-white border-gray-300 text-gray-900'
                                        }`}
                                    />
                                </div>
                            </div>

                            {/* Bio */}
                            <div className="md:col-span-2">
                                <label className={`block text-sm font-medium mb-2 ${
                                    isDarkMode ? 'text-gray-300' : 'text-gray-700'
                                }`}>
                                    Bio
                                </label>
                                <textarea
                                    name="bio"
                                    value={formData.bio}
                                    onChange={handleChange}
                                    disabled={!isEditing}
                                    rows="4"
                                    className={`w-full px-4 py-2 rounded-lg border ${
                                        isDarkMode
                                            ? 'bg-gray-700 border-gray-600 text-gray-100'
                                            : 'bg-white border-gray-300 text-gray-900'
                                    }`}
                                />
                            </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex justify-end space-x-4">
                            {isEditing ? (
                                <>
                                    <button
                                        type="button"
                                        onClick={() => setIsEditing(false)}
                                        className={`px-4 py-2 rounded-lg ${
                                            isDarkMode
                                                ? 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                                                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                        }`}
                                    >
                                        Cancel
                                    </button>
                                    <button
                                        type="submit"
                                        className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700"
                                    >
                                        Save Changes
                                    </button>
                                </>
                            ) : (
                                <button
                                    type="button"
                                    onClick={() => setIsEditing(true)}
                                    className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700"
                                >
                                    Edit Profile
                                </button>
                            )}
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default Profile; 