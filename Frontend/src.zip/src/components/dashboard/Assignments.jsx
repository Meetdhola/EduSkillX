import React, { useState, useEffect } from 'react';
import { FaPlus, FaFileAlt, FaClock, FaCheckCircle, FaTimesCircle } from 'react-icons/fa';
import { useTheme } from '../../context/ThemeContext';
import axios from 'axios';

const Assignments = () => {
    const { isDarkMode } = useTheme();
    const [assignments, setAssignments] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [userRole, setUserRole] = useState(null);
    const [showCreateForm, setShowCreateForm] = useState(false);
    const [newAssignment, setNewAssignment] = useState({
        title: '',
        description: '',
        dueDate: '',
        courseId: ''
    });

    useEffect(() => {
        const user = JSON.parse(localStorage.getItem('user'));
        setUserRole(user?.role);
        fetchAssignments();
    }, []);

    const fetchAssignments = async () => {
        try {
            const token = localStorage.getItem('token');
            const endpoint = userRole === 'tutor' 
                ? `${import.meta.env.VITE_BASE_URI}/tutor/assignments`
                : `${import.meta.env.VITE_BASE_URI}/student/assignments`;
            
            const response = await axios.get(endpoint, {
                headers: { Authorization: `Bearer ${token}` }
            });
            setAssignments(response.data.assignments);
        } catch (error) {
            console.error('Error fetching assignments:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const handleCreateAssignment = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem('token');
            await axios.post(
                `${import.meta.env.VITE_BASE_URI}/tutor/assignments`,
                newAssignment,
                {
                    headers: { Authorization: `Bearer ${token}` }
                }
            );
            setShowCreateForm(false);
            setNewAssignment({
                title: '',
                description: '',
                dueDate: '',
                courseId: ''
            });
            fetchAssignments();
        } catch (error) {
            console.error('Error creating assignment:', error);
        }
    };

    const handleSubmitAssignment = async (assignmentId) => {
        try {
            const token = localStorage.getItem('token');
            await axios.post(
                `${import.meta.env.VITE_BASE_URI}/student/assignments/${assignmentId}/submit`,
                {},
                {
                    headers: { Authorization: `Bearer ${token}` }
                }
            );
            fetchAssignments();
        } catch (error) {
            console.error('Error submitting assignment:', error);
        }
    };

    if (isLoading) {
        return (
            <div className="flex justify-center items-center h-full">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
            </div>
        );
    }

    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">Assignments</h1>
                {userRole === 'tutor' && (
                    <button
                        onClick={() => setShowCreateForm(true)}
                        className={`flex items-center px-4 py-2 rounded-lg ${
                            isDarkMode
                                ? 'bg-blue-600 hover:bg-blue-700'
                                : 'bg-blue-500 hover:bg-blue-600'
                        } text-white`}
                    >
                        <FaPlus className="mr-2" />
                        Create Assignment
                    </button>
                )}
            </div>

            {/* Create Assignment Form */}
            {showCreateForm && (
                <div className={`mb-6 p-4 rounded-lg ${
                    isDarkMode ? 'bg-gray-800' : 'bg-white'
                } shadow-lg`}>
                    <h2 className="text-xl font-semibold mb-4">Create New Assignment</h2>
                    <form onSubmit={handleCreateAssignment} className="space-y-4">
                        <div>
                            <label className="block mb-2">Title</label>
                            <input
                                type="text"
                                value={newAssignment.title}
                                onChange={(e) => setNewAssignment({...newAssignment, title: e.target.value})}
                                className={`w-full px-4 py-2 rounded-lg border ${
                                    isDarkMode
                                        ? 'bg-gray-700 border-gray-600 text-white'
                                        : 'bg-white border-gray-300'
                                }`}
                                required
                            />
                        </div>
                        <div>
                            <label className="block mb-2">Description</label>
                            <textarea
                                value={newAssignment.description}
                                onChange={(e) => setNewAssignment({...newAssignment, description: e.target.value})}
                                className={`w-full px-4 py-2 rounded-lg border ${
                                    isDarkMode
                                        ? 'bg-gray-700 border-gray-600 text-white'
                                        : 'bg-white border-gray-300'
                                }`}
                                rows="4"
                                required
                            />
                        </div>
                        <div>
                            <label className="block mb-2">Due Date</label>
                            <input
                                type="datetime-local"
                                value={newAssignment.dueDate}
                                onChange={(e) => setNewAssignment({...newAssignment, dueDate: e.target.value})}
                                className={`w-full px-4 py-2 rounded-lg border ${
                                    isDarkMode
                                        ? 'bg-gray-700 border-gray-600 text-white'
                                        : 'bg-white border-gray-300'
                                }`}
                                required
                            />
                        </div>
                        <div className="flex justify-end space-x-4">
                            <button
                                type="button"
                                onClick={() => setShowCreateForm(false)}
                                className={`px-4 py-2 rounded-lg ${
                                    isDarkMode
                                        ? 'bg-gray-700 hover:bg-gray-600'
                                        : 'bg-gray-200 hover:bg-gray-300'
                                }`}
                            >
                                Cancel
                            </button>
                            <button
                                type="submit"
                                className={`px-4 py-2 rounded-lg ${
                                    isDarkMode
                                        ? 'bg-blue-600 hover:bg-blue-700'
                                        : 'bg-blue-500 hover:bg-blue-600'
                                } text-white`}
                            >
                                Create
                            </button>
                        </div>
                    </form>
                </div>
            )}

            {/* Assignments List */}
            <div className="grid gap-6">
                {assignments.map((assignment) => (
                    <div
                        key={assignment._id}
                        className={`p-6 rounded-lg shadow-lg ${
                            isDarkMode ? 'bg-gray-800' : 'bg-white'
                        }`}
                    >
                        <div className="flex justify-between items-start">
                            <div>
                                <h3 className="text-xl font-semibold mb-2">{assignment.title}</h3>
                                <p className={`mb-4 ${
                                    isDarkMode ? 'text-gray-300' : 'text-gray-600'
                                }`}>
                                    {assignment.description}
                                </p>
                                <div className="flex items-center space-x-4">
                                    <div className="flex items-center">
                                        <FaClock className={`mr-2 ${
                                            isDarkMode ? 'text-gray-400' : 'text-gray-500'
                                        }`} />
                                        <span>Due: {new Date(assignment.dueDate).toLocaleString()}</span>
                                    </div>
                                    {userRole === 'student' && (
                                        <div className="flex items-center">
                                            {assignment.submitted ? (
                                                <FaCheckCircle className="text-green-500 mr-2" />
                                            ) : (
                                                <FaTimesCircle className="text-red-500 mr-2" />
                                            )}
                                            <span>{assignment.submitted ? 'Submitted' : 'Not Submitted'}</span>
                                        </div>
                                    )}
                                </div>
                            </div>
                            {userRole === 'student' && !assignment.submitted && (
                                <button
                                    onClick={() => handleSubmitAssignment(assignment._id)}
                                    className={`px-4 py-2 rounded-lg ${
                                        isDarkMode
                                            ? 'bg-green-600 hover:bg-green-700'
                                            : 'bg-green-500 hover:bg-green-600'
                                    } text-white`}
                                >
                                    Submit
                                </button>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Assignments; 