import React, { useState, useEffect } from 'react';
import { FaUser, FaLock, FaBell, FaPalette } from 'react-icons/fa';
import { useTheme } from '../../context/ThemeContext';
import axios from 'axios';

const Settings = () => {
    const { isDarkMode, toggleTheme } = useTheme();
    const [activeTab, setActiveTab] = useState('profile');
    const [isLoading, setIsLoading] = useState(false);
    const [user, setUser] = useState(null);
    const [formData, setFormData] = useState({
        firstname: '',
        lastname: '',
        email: '',
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
    });
    const [notifications, setNotifications] = useState({
        email: true,
        push: true,
        courseUpdates: true,
        assignmentReminders: true
    });

    useEffect(() => {
        fetchUserData();
    }, []);

    const fetchUserData = async () => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get(`${import.meta.env.VITE_BASE_URI}/user/profile`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            setUser(response.data.user);
            setFormData({
                firstname: response.data.user.Fullname.firstname,
                lastname: response.data.user.Fullname.lastname,
                email: response.data.user.email,
                currentPassword: '',
                newPassword: '',
                confirmPassword: ''
            });
        } catch (error) {
            console.error('Error fetching user data:', error);
        }
    };

    const handleProfileUpdate = async (e) => {
        e.preventDefault();
        setIsLoading(true);
        try {
            const token = localStorage.getItem('token');
            await axios.put(
                `${import.meta.env.VITE_BASE_URI}/user/profile`,
                {
                    firstname: formData.firstname,
                    lastname: formData.lastname,
                    email: formData.email
                },
                {
                    headers: { Authorization: `Bearer ${token}` }
                }
            );
            fetchUserData();
        } catch (error) {
            console.error('Error updating profile:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const handlePasswordChange = async (e) => {
        e.preventDefault();
        if (formData.newPassword !== formData.confirmPassword) {
            alert('New passwords do not match');
            return;
        }
        setIsLoading(true);
        try {
            const token = localStorage.getItem('token');
            await axios.put(
                `${import.meta.env.VITE_BASE_URI}/user/password`,
                {
                    currentPassword: formData.currentPassword,
                    newPassword: formData.newPassword
                },
                {
                    headers: { Authorization: `Bearer ${token}` }
                }
            );
            setFormData({
                ...formData,
                currentPassword: '',
                newPassword: '',
                confirmPassword: ''
            });
        } catch (error) {
            console.error('Error changing password:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const handleNotificationToggle = async (key) => {
        try {
            const token = localStorage.getItem('token');
            await axios.put(
                `${import.meta.env.VITE_BASE_URI}/user/notifications`,
                {
                    [key]: !notifications[key]
                },
                {
                    headers: { Authorization: `Bearer ${token}` }
                }
            );
            setNotifications(prev => ({
                ...prev,
                [key]: !prev[key]
            }));
        } catch (error) {
            console.error('Error updating notification settings:', error);
        }
    };

    return (
        <div className="p-6">
            <h1 className="text-2xl font-bold mb-6">Settings</h1>

            {/* Settings Navigation */}
            <div className="flex space-x-4 mb-6">
                <button
                    onClick={() => setActiveTab('profile')}
                    className={`px-4 py-2 rounded-lg flex items-center ${
                        activeTab === 'profile'
                            ? isDarkMode
                                ? 'bg-blue-600 text-white'
                                : 'bg-blue-500 text-white'
                            : isDarkMode
                                ? 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                >
                    <FaUser className="mr-2" />
                    Profile
                </button>
                <button
                    onClick={() => setActiveTab('security')}
                    className={`px-4 py-2 rounded-lg flex items-center ${
                        activeTab === 'security'
                            ? isDarkMode
                                ? 'bg-blue-600 text-white'
                                : 'bg-blue-500 text-white'
                            : isDarkMode
                                ? 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                >
                    <FaLock className="mr-2" />
                    Security
                </button>
                <button
                    onClick={() => setActiveTab('notifications')}
                    className={`px-4 py-2 rounded-lg flex items-center ${
                        activeTab === 'notifications'
                            ? isDarkMode
                                ? 'bg-blue-600 text-white'
                                : 'bg-blue-500 text-white'
                            : isDarkMode
                                ? 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                >
                    <FaBell className="mr-2" />
                    Notifications
                </button>
                <button
                    onClick={() => setActiveTab('appearance')}
                    className={`px-4 py-2 rounded-lg flex items-center ${
                        activeTab === 'appearance'
                            ? isDarkMode
                                ? 'bg-blue-600 text-white'
                                : 'bg-blue-500 text-white'
                            : isDarkMode
                                ? 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                >
                    <FaPalette className="mr-2" />
                    Appearance
                </button>
            </div>

            {/* Profile Settings */}
            {activeTab === 'profile' && (
                <div className={`p-6 rounded-lg ${
                    isDarkMode ? 'bg-gray-800' : 'bg-white'
                } shadow-lg`}>
                    <h2 className="text-xl font-semibold mb-4">Profile Settings</h2>
                    <form onSubmit={handleProfileUpdate} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block mb-2">First Name</label>
                                <input
                                    type="text"
                                    value={formData.firstname}
                                    onChange={(e) => setFormData({...formData, firstname: e.target.value})}
                                    className={`w-full px-4 py-2 rounded-lg border ${
                                        isDarkMode
                                            ? 'bg-gray-700 border-gray-600 text-white'
                                            : 'bg-white border-gray-300'
                                    }`}
                                    required
                                />
                            </div>
                            <div>
                                <label className="block mb-2">Last Name</label>
                                <input
                                    type="text"
                                    value={formData.lastname}
                                    onChange={(e) => setFormData({...formData, lastname: e.target.value})}
                                    className={`w-full px-4 py-2 rounded-lg border ${
                                        isDarkMode
                                            ? 'bg-gray-700 border-gray-600 text-white'
                                            : 'bg-white border-gray-300'
                                    }`}
                                    required
                                />
                            </div>
                        </div>
                        <div>
                            <label className="block mb-2">Email</label>
                            <input
                                type="email"
                                value={formData.email}
                                onChange={(e) => setFormData({...formData, email: e.target.value})}
                                className={`w-full px-4 py-2 rounded-lg border ${
                                    isDarkMode
                                        ? 'bg-gray-700 border-gray-600 text-white'
                                        : 'bg-white border-gray-300'
                                }`}
                                required
                            />
                        </div>
                        <button
                            type="submit"
                            disabled={isLoading}
                            className={`px-4 py-2 rounded-lg ${
                                isDarkMode
                                    ? 'bg-blue-600 hover:bg-blue-700'
                                    : 'bg-blue-500 hover:bg-blue-600'
                            } text-white`}
                        >
                            {isLoading ? 'Saving...' : 'Save Changes'}
                        </button>
                    </form>
                </div>
            )}

            {/* Security Settings */}
            {activeTab === 'security' && (
                <div className={`p-6 rounded-lg ${
                    isDarkMode ? 'bg-gray-800' : 'bg-white'
                } shadow-lg`}>
                    <h2 className="text-xl font-semibold mb-4">Change Password</h2>
                    <form onSubmit={handlePasswordChange} className="space-y-4">
                        <div>
                            <label className="block mb-2">Current Password</label>
                            <input
                                type="password"
                                value={formData.currentPassword}
                                onChange={(e) => setFormData({...formData, currentPassword: e.target.value})}
                                className={`w-full px-4 py-2 rounded-lg border ${
                                    isDarkMode
                                        ? 'bg-gray-700 border-gray-600 text-white'
                                        : 'bg-white border-gray-300'
                                }`}
                                required
                            />
                        </div>
                        <div>
                            <label className="block mb-2">New Password</label>
                            <input
                                type="password"
                                value={formData.newPassword}
                                onChange={(e) => setFormData({...formData, newPassword: e.target.value})}
                                className={`w-full px-4 py-2 rounded-lg border ${
                                    isDarkMode
                                        ? 'bg-gray-700 border-gray-600 text-white'
                                        : 'bg-white border-gray-300'
                                }`}
                                required
                            />
                        </div>
                        <div>
                            <label className="block mb-2">Confirm New Password</label>
                            <input
                                type="password"
                                value={formData.confirmPassword}
                                onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                                className={`w-full px-4 py-2 rounded-lg border ${
                                    isDarkMode
                                        ? 'bg-gray-700 border-gray-600 text-white'
                                        : 'bg-white border-gray-300'
                                }`}
                                required
                            />
                        </div>
                        <button
                            type="submit"
                            disabled={isLoading}
                            className={`px-4 py-2 rounded-lg ${
                                isDarkMode
                                    ? 'bg-blue-600 hover:bg-blue-700'
                                    : 'bg-blue-500 hover:bg-blue-600'
                            } text-white`}
                        >
                            {isLoading ? 'Updating...' : 'Update Password'}
                        </button>
                    </form>
                </div>
            )}

            {/* Notification Settings */}
            {activeTab === 'notifications' && (
                <div className={`p-6 rounded-lg ${
                    isDarkMode ? 'bg-gray-800' : 'bg-white'
                } shadow-lg`}>
                    <h2 className="text-xl font-semibold mb-4">Notification Preferences</h2>
                    <div className="space-y-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <h3 className="font-medium">Email Notifications</h3>
                                <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                                    Receive notifications via email
                                </p>
                            </div>
                            <button
                                onClick={() => handleNotificationToggle('email')}
                                className={`relative inline-flex h-6 w-11 items-center rounded-full ${
                                    notifications.email
                                        ? isDarkMode
                                            ? 'bg-blue-600'
                                            : 'bg-blue-500'
                                        : isDarkMode
                                            ? 'bg-gray-700'
                                            : 'bg-gray-300'
                                }`}
                            >
                                <span
                                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                                        notifications.email ? 'translate-x-6' : 'translate-x-1'
                                    }`}
                                />
                            </button>
                        </div>
                        <div className="flex items-center justify-between">
                            <div>
                                <h3 className="font-medium">Push Notifications</h3>
                                <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                                    Receive push notifications in browser
                                </p>
                            </div>
                            <button
                                onClick={() => handleNotificationToggle('push')}
                                className={`relative inline-flex h-6 w-11 items-center rounded-full ${
                                    notifications.push
                                        ? isDarkMode
                                            ? 'bg-blue-600'
                                            : 'bg-blue-500'
                                        : isDarkMode
                                            ? 'bg-gray-700'
                                            : 'bg-gray-300'
                                }`}
                            >
                                <span
                                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                                        notifications.push ? 'translate-x-6' : 'translate-x-1'
                                    }`}
                                />
                            </button>
                        </div>
                        <div className="flex items-center justify-between">
                            <div>
                                <h3 className="font-medium">Course Updates</h3>
                                <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                                    Get notified about course updates
                                </p>
                            </div>
                            <button
                                onClick={() => handleNotificationToggle('courseUpdates')}
                                className={`relative inline-flex h-6 w-11 items-center rounded-full ${
                                    notifications.courseUpdates
                                        ? isDarkMode
                                            ? 'bg-blue-600'
                                            : 'bg-blue-500'
                                        : isDarkMode
                                            ? 'bg-gray-700'
                                            : 'bg-gray-300'
                                }`}
                            >
                                <span
                                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                                        notifications.courseUpdates ? 'translate-x-6' : 'translate-x-1'
                                    }`}
                                />
                            </button>
                        </div>
                        <div className="flex items-center justify-between">
                            <div>
                                <h3 className="font-medium">Assignment Reminders</h3>
                                <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                                    Get reminded about upcoming assignments
                                </p>
                            </div>
                            <button
                                onClick={() => handleNotificationToggle('assignmentReminders')}
                                className={`relative inline-flex h-6 w-11 items-center rounded-full ${
                                    notifications.assignmentReminders
                                        ? isDarkMode
                                            ? 'bg-blue-600'
                                            : 'bg-blue-500'
                                        : isDarkMode
                                            ? 'bg-gray-700'
                                            : 'bg-gray-300'
                                }`}
                            >
                                <span
                                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                                        notifications.assignmentReminders ? 'translate-x-6' : 'translate-x-1'
                                    }`}
                                />
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Appearance Settings */}
            {activeTab === 'appearance' && (
                <div className={`p-6 rounded-lg ${
                    isDarkMode ? 'bg-gray-800' : 'bg-white'
                } shadow-lg`}>
                    <h2 className="text-xl font-semibold mb-4">Appearance Settings</h2>
                    <div className="space-y-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <h3 className="font-medium">Dark Mode</h3>
                                <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                                    Switch between light and dark theme
                                </p>
                            </div>
                            <button
                                onClick={toggleTheme}
                                className={`relative inline-flex h-6 w-11 items-center rounded-full ${
                                    isDarkMode
                                        ? 'bg-blue-600'
                                        : 'bg-gray-300'
                                }`}
                            >
                                <span
                                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                                        isDarkMode ? 'translate-x-6' : 'translate-x-1'
                                    }`}
                                />
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Settings; 