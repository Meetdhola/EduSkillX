import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import LoginPage from './components/LoginPage'
import ARVR from './components/ArVr'
// import CourseVerification from './components/Courseverfication'
import UserLogin from './components/auth/UserLogin'
import UserSignup from './components/auth/UserSignup'
import Home from './components/Home'
import Dashboard from './components/Dashboard'
import { ThemeProvider } from './context/ThemeContext'
import UserContext from './context/userContext'
import PrivateRoute from './components/PrivateRoute'
import './App.css'

const App = () => {
  return (
    <Router>
      <ThemeProvider>
        <UserContext>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/signup" element={<UserSignup />} />
            <Route path="/arvr" element={<ARVR/>} />
            
            {/* <Route path="/CourseVerification" element={<CourseVerification/>} /> */}
            <Route
              path="/dashboard/*"
              element={
                <PrivateRoute>
                  <Dashboard />
                </PrivateRoute>
              }
            />
          </Routes>
        </UserContext>
      </ThemeProvider>
    </Router>
  )
}

export default App
